/**
 * \file FindOpenHaptics.cpp
 * \brief C++ source file used by CMake module FindOpenHaptics.cmake
 *
 * \author
 * Ryan Pavlik, 2009-2010
 * <rpavlik@iastate.edu>
 * http://academic.cleardefinition.com/
 *
 * Used to check stdc++ version
 *
 */

#include <HD/hd.h>

int main(int argc, char* argv[]) {
	return 0;
}
